document.addEventListener("DOMContentLoaded", function(){
    document.body.innerHTML += "<h1>Welcome to your life, there is no turning back</h1>"
})