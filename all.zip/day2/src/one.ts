var hero:string = "Batman";
    hero = "555";
var heropower:number = 7;

// let heroes:string[] = ["Batman","Superman","Ironman"];
let heroes:Array<string> = ["Batman","Superman","Ironman"];

let movieCount:( number | string );
/*
movieCount = 5;
movieCount = "hello";
*/
// movieCount = false;

/*
if( movieCount instanceof Number){
 
}
*/



let city:any;


console.log(hero);