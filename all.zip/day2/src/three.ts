interface IHero{
    city:string;
    power?:number;
    sayfullname():string;
}

class Hero implements IHero{
    city:string = "Gotham";
    power:number = 7;
    constructor(
        private fname:string,
        private lname:string
        ){}
    sayfullname():string{
        return this.fname+" "+this.lname;
    }
    get modifyfname(){
        return this.fname
    }
    set modifyfname(val:string){
        this.fname = val
    }
};
let phantom = new Hero("Peter","Parker");
console.log(phantom.sayfullname());