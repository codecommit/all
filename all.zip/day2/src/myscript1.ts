var herolist = [
    { title : "Batman", power : 7 },
    { title : "Ironman", power : 8 },
    { title : "Spiderman", power : 5 },
    { title : "Superman", power : 10 },
    { title : "Hulk", power : 9 },
    { title : "Antman", power : 6 }
];