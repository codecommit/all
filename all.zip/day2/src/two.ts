/*
function myfun(arg:string):void{
    "hi"+arg
};
var val = myfun('batman');

console.log(myfun('batman'));
*/
/*
*/
let adder = function(num1:number = 0, num2:number = 0, num3?:number ){
    if(num3){
        return num1+num2+num3
    }else{
        return num1+num2
    }
};    

console.log(adder(5,6,7));// 11
console.log(adder(5,6));// 11
console.log(adder(5));// 11