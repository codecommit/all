var Heroin = /** @class */ (function () {
    function Heroin(fn, ln, city) {
        this.fname = fn;
        this.lname = ln;
        this.city = city;
    }
    Heroin.prototype.fullname = function () {
        return this.fname + " " + this.lname;
    };
    return Heroin;
}());
export { Heroin };
