"use strict";
var hero = "Batman";
hero = "555";
var heropower = 7;
// let heroes:string[] = ["Batman","Superman","Ironman"];
var heroes = ["Batman", "Superman", "Ironman"];
var movieCount;
/*
movieCount = 5;
movieCount = "hello";
*/
// movieCount = false;
/*
if( movieCount instanceof Number){
 
}
*/
var city;
console.log(hero);
