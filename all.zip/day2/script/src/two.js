"use strict";
/*
function myfun(arg:string):void{
    "hi"+arg
};
var val = myfun('batman');

console.log(myfun('batman'));
*/
/*
*/
var adder = function (num1, num2, num3) {
    if (num1 === void 0) { num1 = 0; }
    if (num2 === void 0) { num2 = 0; }
    if (num3) {
        return num1 + num2 + num3;
    }
    else {
        return num1 + num2;
    }
};
console.log(adder(5, 6, 7)); // 11
console.log(adder(5, 6)); // 11
console.log(adder(5)); // 11
