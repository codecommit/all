"use strict";
var Hero = /** @class */ (function () {
    function Hero(fname, lname) {
        this.fname = fname;
        this.lname = lname;
        this.city = "Gotham";
        this.power = 7;
    }
    Hero.prototype.sayfullname = function () {
        return this.fname + " " + this.lname;
    };
    Object.defineProperty(Hero.prototype, "modifyfname", {
        get: function () {
            return this.fname;
        },
        set: function (val) {
            this.fname = val;
        },
        enumerable: true,
        configurable: true
    });
    return Hero;
}());
;
var phantom = new Hero("Peter", "Parker");
console.log(phantom.sayfullname());
