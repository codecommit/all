"use strict";
var herolist = [
    { title: "Batman", power: 7 },
    { title: "Ironman", power: 8 },
    { title: "Spiderman", power: 5 },
    { title: "Superman", power: 10 },
    { title: "Hulk", power: 9 },
    { title: "Antman", power: 6 }
];
function sorthero(hero1, hero2) {
    if (hero1.power < hero2.power) {
        return 1;
    }
    else if (hero1.power > hero2.power) {
        return -1;
    }
    else {
        return 0;
    }
}
;
console.log(herolist.sort(sorthero));
