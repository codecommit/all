"use strict";
console.log(herolist.sort(sorthero));
